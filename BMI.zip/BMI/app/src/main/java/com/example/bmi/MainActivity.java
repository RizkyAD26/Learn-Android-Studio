package com.example.bmi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText bionama, biousia, bioberat, biotinggi;
    TextView tampilnama, tampilusia, tampilberat, tampiltinggi, tampilbmi, tampilwho, tampilasia;
    Button tmblproses, tmblexit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bionama = (EditText) findViewById(R.id.namau);
        biousia = (EditText) findViewById(R.id.usiau);
        bioberat = (EditText) findViewById(R.id.bbu);
        biotinggi = (EditText) findViewById(R.id.tbu);
        tampilnama = (TextView) findViewById(R.id.hnama);
        tampilusia = (TextView) findViewById(R.id.husia);
        tampilberat = (TextView) findViewById(R.id.hbb);
        tampiltinggi = (TextView) findViewById(R.id.htb);
        tampilbmi = (TextView) findViewById(R.id.hbmi);
        tampilwho = (TextView) findViewById(R.id.hwho);
        tampilasia = (TextView) findViewById(R.id.hasia);
        tmblproses = (Button) findViewById(R.id.proses);
        tmblexit = (Button) findViewById(R.id.keluar);

        tmblproses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name, age, weight, height;
                float berat = Integer.parseInt(bioberat.getText().toString());
                float tinggi = Integer.parseInt(biotinggi.getText().toString());
                float ptinggi = tinggi / 100;
                float hasil = berat / (ptinggi * ptinggi);
                float value = (float) hasil;
                String swho;
                String sasia;
                if (hasil <= 18.5) {
                    swho = "Kurus";
                } else if (hasil >= 18.5 && hasil <24.9) {
                    swho= "Normal";
                } else if (hasil >= 25 && hasil < 29.9) {
                    swho = "Overweight";
                } else {
                    swho = "Obesitas";
                }
                if (hasil <= 18.5) {
                    sasia = "Kurus";
                } else if (hasil >= 18.5 && hasil <22.9) {
                    sasia = "Normal";
                } else if (hasil >= 23 && hasil <24.9) {
                    sasia = "Overweight";
                } else {
                    sasia = "Obesitas";
                }
                name = bionama.getText().toString().trim();
                age = biousia.getText().toString().trim();
                weight = bioberat.getText().toString().trim();
                height = biotinggi.getText().toString().trim();
                tampilnama.setText(name);
                tampilusia.setText(age);
                tampilberat.setText(weight);
                tampiltinggi.setText(height);
                tampilwho.setText(swho);
                tampilasia.setText(sasia);
                tampilbmi.setText(String.valueOf(hasil));
                Toast.makeText(getApplicationContext(), "Data Telah Selesai Dihitung",Toast.LENGTH_LONG).show();
            }
        });
        tmblexit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                System.exit(0);
            }
        });
    }
}
